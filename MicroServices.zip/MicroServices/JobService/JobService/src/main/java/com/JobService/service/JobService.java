package com.JobService.service;

import com.JobService.DTO.UserDTO;
import com.JobService.client.UserClient;
import com.JobService.entity.Job;
import com.JobService.repository.JobRepository;

public class JobService {

    private JobRepository jobRepository;
    private UserClient userClient;

    public Job createJob(Job job) {

        // CALL USER SERVICE
        UserDTO user = userClient.getUser(job.getRecruiterId());

        if (user == null) {
            throw new RuntimeException("Recruiter not found");
        }

        return jobRepository.save(job);
    }

}
